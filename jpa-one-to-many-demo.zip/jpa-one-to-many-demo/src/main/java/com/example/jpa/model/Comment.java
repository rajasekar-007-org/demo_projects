package com.example.jpa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.jpa.repository.PostRepository;

/**
 * Created by rajeevkumarsingh on 21/11/17.
 */
@Entity
@Table(name = "comments")
public class Comment extends AuditModel {
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="COM_ID", unique = true, nullable = false)
    private Long comId;

    @NotNull
    @Lob
    private String text;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "post_id")
    /*@OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class, property="id")
    @JsonIdentityReference(alwaysAsId=true)
    @JsonProperty("post_id")*/
    private Post post;

    public Long getComId() {
		return comId;
	}

	public void setComId(Long comId) {
		this.comId = comId;
	}

	public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Post getPost() {
        return post;
    }

    public void setPost(Post post) {
        this.post = post;
    }
    
    /*public void savePost(@Valid Post post) {
        post.getComments().stream()
           .forEach(comment -> {
              comment.setPost(post);
           });
        postRepository.save(post);
    }*/
    
}
